

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="alert alert-danger text-center">
        <h2>Insufficient Credit!</h2>
        <p>You don't have enough credit to complete this purchase.</p>
        <p>Current Credit: ₱<?php echo e(number_format(Auth::user()->credit, 2)); ?></p>
        <a href="<?php echo e(route('products_list')); ?>" class="btn btn-primary">
            Return to Products
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rebuy\OneDrive\Documents\GitHub\websec\WebSecService\resources\views/errors/insufficient_balance.blade.php ENDPATH**/ ?>