<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('products_save', $product->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger">
        <strong>Error!</strong> <?php echo e($error); ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <div class="row mb-2">
        <div class="col-6">
            <label for="code" class="form-label">Code:</label>
            <input type="text" class="form-control" placeholder="Code" name="code" required value="<?php echo e($product->code); ?>">
        </div>
        <div class="col-6">
            <label for="model" class="form-label">Model:</label>
            <input type="text" class="form-control" placeholder="Model" name="model" required value="<?php echo e($product->model); ?>">
        </div>
    </div>
    
    <div class="row mb-2">
        <div class="col">
            <label for="name" class="form-label">Name:</label>
            <input type="text" class="form-control" placeholder="Name" name="name" required value="<?php echo e($product->name); ?>">
        </div>
    </div>
    
    <div class="row mb-2">
        <div class="col-4">
            <label for="price" class="form-label">Price:</label>
            <input type="number" step="0.01" class="form-control" placeholder="Price" name="price" required value="<?php echo e($product->price); ?>">
        </div>
        <div class="col-4">
            <label for="inventory" class="form-label">Amount:</label>
            <input type="number" class="form-control" placeholder="Quantity" name="inventory" min="0" required value="<?php echo e($product->inventory ?? 0); ?>">
        </div>
        <div class="col-4">
            <label for="photo" class="form-label">Photo:</label>
            <input type="text" class="form-control" placeholder="Photo URL" name="photo" value="<?php echo e($product->photo); ?>">
            <?php if($product->photo): ?>
                <img src="<?php echo e(asset($product->photo)); ?>" width="50" class="mt-2">
            <?php endif; ?>
        </div>
    </div>
    
    <div class="row mb-2">
        <div class="col">
            <label for="description" class="form-label">Description:</label>
            <textarea class="form-control" placeholder="Description" name="description" required><?php echo e($product->description); ?></textarea>
        </div>
    </div>
    
    <div class="row mb-4">
        <div class="col">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="is_active" id="is_active" value="1" <?php echo e($product->is_active ? 'checked' : ''); ?>>
                <label class="form-check-label" for="is_active">
                    Product is active
                </label>
            </div>
        </div>
    </div>
    
    <button type="submit" class="btn btn-primary">Save Product</button>
    <a href="<?php echo e(route('products_list')); ?>" class="btn btn-secondary">Cancel</a>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rebuy\OneDrive\Documents\GitHub\websec\WebSecService\resources\views/products/edit.blade.php ENDPATH**/ ?>