<?php $__env->startSection('title', 'Test Page'); ?>
<?php $__env->startSection('content'); ?>
<div class="row mb-3">
    <div class="col">
        <div class="card bg-light border-info">
            <div class="card-body">
                <h5 class="card-title mb-0">Store Credit</h5>
                <p class="card-text fs-4 text-success">
                    ₱<?php echo e(number_format(Auth::user()->credit, 2)); ?>

                </p>
            </div>
        </div>
    </div>
</div>

<div class="row mt-2">
    <div class="col col-10">
        <h1>Products</h1>
    </div>
    <div class="col col-2">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_products')): ?>
        <a href="<?php echo e(route('products_edit')); ?>" class="btn btn-success form-control">Add Product</a>
        <?php endif; ?>
    </div>
</div>

<!-- Search Form -->
<form>
    <div class="row">
        <!-- Existing search fields... -->
        <div class="col col-sm-2">
            <select name="in_Inventory" class="form-select">
                <option value="" <?php echo e(request()->in_Inventory==""?"selected":""); ?>>All Inventory Status</option>
                <option value="1" <?php echo e(request()->in_Inventory=="1"?"selected":""); ?>>In Inventory</option>
                <option value="0" <?php echo e(request()->in_Inventory=="0"?"selected":""); ?>>Out of Inventory</option>
            </select>
        </div>
        <!-- Rest of your search fields... -->
    </div>
</form>

<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card mt-2">
        <div class="card-body">
            <div class="row">
                <div class="col col-sm-12 col-lg-4">
                    <img src="<?php echo e(asset("images/$product->photo")); ?>" class="img-thumbnail" alt="<?php echo e($product->name); ?>" width="100%">
                </div>
                <div class="col col-sm-12 col-lg-8 mt-3">
                    <div class="row mb-2">
                        <div class="col-8">
                            <h3><?php echo e($product->name); ?></h3>
                            <!-- Inventory Status Badge -->
                            <?php if($product->inventory > 0): ?>
                                <span class="badge bg-success">
                                    <i class="fas fa-check"></i> In Inventory (<?php echo e($product->Inventory); ?> available)
                                </span>
                            <?php else: ?>
                                <span class="badge bg-danger">
                                    <i class="fas fa-times"></i> Out of Inventory
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="col col-2">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_products')): ?>
                            <a href="<?php echo e(route('products_edit', $product->id)); ?>" class="btn btn-success form-control">Edit</a>
                            <?php endif; ?>
                        </div>
                        <div class="col col-2">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_products')): ?>
                            <a href="<?php echo e(route('products_delete', $product->id)); ?>" class="btn btn-danger form-control">Delete</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Buy Button with Inventory Check -->
                    <div class="col col-2">
                        <form action="<?php echo e(route('products.purchase', $product->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary form-control" 
                                <?php echo e($product->inventory < 1 ? 'disabled' : ''); ?>>
                                Buy
                            </button>
                            <?php if($product->inventory < 1): ?>
                                <small class="text-danger">Out of Inventory</small>
                            <?php endif; ?>
                        </form>
                    </div>

                    <table class="table table-striped">
                        <tr><th width="20%">Name</th><td><?php echo e($product->name); ?></td></tr>
                        <tr><th>Model</th><td><?php echo e($product->model); ?></td></tr>
                        <tr><th>Code</th><td><?php echo e($product->code); ?></td></tr>
                        <tr><th>Price</th><td>₱<?php echo e(number_format($product->price, 2)); ?></td></tr>
                        <tr><th>Inventory</th><td><?php echo e($product->Inventory); ?></td></tr>
                        <tr><th>Description</th><td><?php echo e($product->description); ?></td></tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rebuy\OneDrive\Documents\GitHub\websec\WebSecService\resources\views/products/list.blade.php ENDPATH**/ ?>